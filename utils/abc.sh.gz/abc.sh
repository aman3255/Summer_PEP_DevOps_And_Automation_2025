#!/bin/bash

echo "$HI"


